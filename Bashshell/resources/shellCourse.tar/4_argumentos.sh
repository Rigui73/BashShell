#!/bin/bash
# Description: Programa para simplificar el paso de argumentos
# Author: Adria Rigall - @rigui73

nombreCurso=$1
horarioCurso=$2

echo "El nombre del curso es: $nombreCurso dictado en el horario de $horarioCurso"
