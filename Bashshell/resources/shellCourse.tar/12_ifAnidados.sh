#!/bin/bash
# Function: Programa para ejemplificar el uso de la sentencia If/Else
# Author: Adria Rigall - @rigui73

notaClase=0
continua=""

echo "Ejemplo Sentencia If -else"
read -n1 -p "indique cual es su nota (1-9): " notaClase
echo -e "\n"
if [ $notaClase -ge 7 ]; then
  echo "El alumno aprueba la materia"
  read -p "Si va continuar estudiando en el siguiente nivel (s/n): " continua
  if [ $continua = "s" ]; then
    echo "Bienvenido al siguiente nivel"
  else
    echo "Gracias por trabajar juntos"
  fi
else
  echo "El alumno reprueba la materia"
fi
