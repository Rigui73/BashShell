#!/bin/bash
# Function: Programa para ejemplificar el empaquetamiento con el comando tar.
# Author: Adria Rigall - @rigui73

echo "Empaquetar todas ls scripts de la carpeta Resources"
tar -cvf shellCourse.tar *.sh
