#!/bin/bash
# Description: Programa para ejemplificar como se realiza el paso de opcioiones con/sin parametros
# Author: Adria Rigall - @rigui73


echo "descargar informacion de internet"
wget hhtps://www-us.apache.org/dist/tomcat/tomcat-8/v8.5.35/bin/apache-tomcat-8.5.35.zip
