#!/bin/bash
# Description: El primer "Hola Mundo" en programación Bash
# Author: Adria Rigall - @rigui73

echo "Hola Mundo"
