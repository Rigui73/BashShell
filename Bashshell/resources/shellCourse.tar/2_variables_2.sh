#!/bin/bash
# Description: Comprobar eclaración de variables entre ficheros
# Author: Adria Rigall - @rigui73

echo "El nombre asignado es: $nombre"
